package com.tambalban;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TambalBanApplicationTests {

	@Test
	void contextLoads() {
	}

}
